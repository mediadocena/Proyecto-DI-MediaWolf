'use strict';

module.exports = function(Noticia) {
    
};
